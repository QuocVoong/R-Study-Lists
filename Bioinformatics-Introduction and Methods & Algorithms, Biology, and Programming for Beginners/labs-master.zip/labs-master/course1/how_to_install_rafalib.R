install.packages("devtools")
library(devtools)
install_github("genomicsclass/dagdata")
install_github("ririzarr/rafalib")
