**means done**

# week 1

- **mike RStudio**

- **mike R refresher**

- **mike Installing Bioconductor and finding help**

- **rafa Exploratory data analysis**

# week 2

- **mike github**

- **rafa Reading microarray raw data**

- **rafa Microarray EDA**

- **mike Mapping algorithms and software**

- **mike NGS EDA**

- **mike Basic Bioconductor infrastructure: IRanges**

- **mike Basic Bioconductor infrastructure: GenomicRanges**

- **mike Basic Bioconductor infrastructure: ExpressionSet and SummarizedExperiment**

# week 3

- **rafa Monte carlo simulation**

- **rafa Permutation tests**

- **mike Expressing experimental design using R formula** 

- **mike Basic inference on microarray part I**

- **mike Basic inference on microarray part II**

# week 4

- **rafa Motivating normalization with EDA**

- **rafa Normalizing microarrays**

# week 5

- **mike Distances, clustering**

- **mike MDS, heatmaps**

- **mike cross-validation**

# week 6

- **rafa Combat, SVA in R**

- **mike PCA and SVD in R**

- TODO: show how to get date from the celfiles.

# week 7

- **mike Using the limma package**

- **mike Mapping features to genes**

- **mike Gene set testing**

# week 8

- **mike Visualizing NGS with Bioconductor, IGV**

- **mike Making NGS read count table in Bioconductor**

- **mike SNVs** 

- **mike RNA-seq**

- **rafa DNA methylation: arrays and NGS**

- **mike ChIP-seq**
