function  b=phi_d(a)

b=(exp(-a)) ./ ((1+exp(-a)).^2) ;

