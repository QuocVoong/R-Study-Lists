function  b=phi(a)

b=1./(1+exp(-a));
