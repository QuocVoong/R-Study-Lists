setwd('C:/Users/enddylan/Desktop/data')
rm(list=ls(all='True'))
ls<-c(0,2,7,9)
data_sets<-c()
mean_data<-c()
mean_data_fft<-c()
for(i in ls){
   data<-read.table(paste('co2a0000364.rd.00',i,sep=''))
   a<-rep(i,64)
   a<-cbind(a,matrix(data[,4],nrow=64,ncol=256))
   mean_data1<-apply(a,2,mean)
   mean_data<-rbind(mean_data,mean_data1)
   data_sets<-rbind(data_sets,a)
} 
#data_sets is 256*257 includes 4 datasets by their dipoles
#mean_data is the datasets after taking mean of 64 dipoles
#par(mfrow = c(2, 2))
#for(i in 60:63){plot(1:256,data_sets[i,2:257],type='l');title(paste('Data 1 No.',i,' dipole',sep=''));}
#par(mfrow = c(2, 2))
#for(i in 1:4){plot(1:256,mean_data[i,2:257],type='l');title(paste('Data ',i,' mean EEG',sep=''));}
par(mfrow = c(2, 2))
fft_data_sets<-c()
for(i in 1:4){
   mean_data_fft1<-fft(mean_data[i,2:257]);
   #plot(1:256,Re(mean_data_fft1),type='l');title(paste('Data ',i,' fft',sep=''));
   #plot(1:256,Im(mean_data_fft1),type='l');title(paste('Data ',i,' fft',sep=''));
   fft_data_sets<-rbind(fft_data_sets,c(ls[i],'r',Re(mean_data_fft1)),c(ls[i],'i',Im(mean_data_fft1)))
   mean_data_fft<-rbind(mean_data_fft,c(ls[i],mean_data_fft1));
}
#generate a dataset(fft_data_sets)that use Real fft value as x axis , use Imagine value as y axis
for(i in seq(1,7,2)){
   plot(fft_data_sets[i,3:258],fft_data_sets[i+1,3:258],xlab='Real FFT Value',ylab='Imagined FFT Value');title(paste('No.',(i+1)/2,' FFT Dataset'))
}