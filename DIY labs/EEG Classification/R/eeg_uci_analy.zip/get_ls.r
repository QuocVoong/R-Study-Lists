#return file lists
get_ls<-function(index,sample_num){
   ls_all<-c(0,2,7,9,10,11,12,14,15,17,18,19,20,22,23,24,25,27,28,30,31,32,34,36,37,38,39,40,41,43,44,45,46,47,48,49,50,54,55,57,58,59,60,61,62,63,65,66,67,70,71,72,73,74,75,77,79,81,83,84,85,86,87,88,89,91,93,94,95,97,98,99,100,101,102,103,105,107,108,109,110,111,114,115,116,117,118,119)
   #len = 88
   len<-length(ls_all)
   if(index=='a'){ls<-ls_all} #'a' means 'all'
   else if(index=='r'){ls<-ls_all[floor(len*runif(sample_num))]} #'r' means 'random' for 30 samples
   else{ls<-ls_all[index]}
   ls
}