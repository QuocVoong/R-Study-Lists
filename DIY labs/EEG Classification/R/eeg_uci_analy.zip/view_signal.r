view_signal<-function(index){
   if(index<10){data<-read.table(paste('co2a0000364.rd.00',index,sep=''))}
   else if(index>9 && index<100){data<-read.table(paste('co2a0000364.rd.0',index,sep=''))}
   else{data<-read.table(paste('co2a0000364.rd.',index,sep=''))}
   col_num<-dim(data)[1]/64
   a<-matrix(data[,4],nrow=64,ncol=col_num)
   mean_data1<-apply(a,2,mean)
   len<-length(mean_data1)
   plot(1:len,mean_data1,xlab='Time',ylab='Voltage',type='l')
   title(paste('Signal for No.',index,' trial',sep=''))
}