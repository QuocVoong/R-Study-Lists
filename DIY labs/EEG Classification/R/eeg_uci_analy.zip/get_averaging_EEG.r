#Return a data frame (length of list * 257) contain trial number in column 1 , voltage values in other columns , 'ls' means trial array
get_averaging_EEG<-function(ls){
   len<-length(ls)
   mean_data<-c()
   for(i in ls){
      if(i<10){data<-read.table(paste('co2a0000364.rd.00',i,sep=''))}
	  else if(i>9 && i<100){data<-read.table(paste('co2a0000364.rd.0',i,sep=''))}
	  else{data<-read.table(paste('co2a0000364.rd.',i,sep=''))}
	  col_num<-dim(data)[1]/64
      a<-matrix(data[,4],nrow=64,ncol=col_num)
      mean_data1<-apply(a,2,mean)
	  mean_data1<-c(i,mean_data1)
      mean_data<-rbind(mean_data,mean_data1)
   } 
   mean_data
}