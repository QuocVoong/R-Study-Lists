#fft_data_sets is the FFT values of every trial classified separately by its real and imagined values , and cut to a half because of geomatricaly the same ((2*len) * 130)
get_fft_EEG<-function(mean_data){
   ls<-mean_data[,1]
   len<-length(ls)
   col_num<-dim(mean_data)[2]
   fft_data_sets<-c()
   for(i in 1:len){
      mean_data_fft1<-fft(mean_data[i,2:col_num]);
      fft_data_sets<-rbind(fft_data_sets,c(ls[i],'r',Re(mean_data_fft1[1:((col_num-1)/2)])),c(ls[i],'i',Im(mean_data_fft1[1:((col_num-1)/2)])))
   }
   rfft<-which(fft_data_sets[,2]=='r')
   ifft<-which(fft_data_sets[,2]=='i')
   fft_data<-c()
   for(i in rfft){fft_data<-rbind(fft_data,fft_data_sets[i,])}
   for(i in ifft){fft_data<-rbind(fft_data,fft_data_sets[i,])}
   fft_data
}