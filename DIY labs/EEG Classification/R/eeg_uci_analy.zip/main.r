#Input a list of trials (index : can be 'a' , 'r' , or number array) and options (can be 'fft' or 'view') , or optional sample number
#if option is 'f' ,and then the fft averaging points of every trial will return
#if option is 'v' , and you will see the exact plot of EEG signal from the number of trial
main<-function(index='r',option,sample_num=30){
   source('get_averaging_EEG.r')
   source('get_ls.r')
   ls<-get_ls(index,sample_num)
   if(option=='f'){
      source('get_fft_EEG.r')
      source('get_fft_data.r')
      fft_data<-get_fft_data(ls)
	  fft_data<-t(fft_data)
	  plot(fft_data,xlab='Re',ylab='Im')
	  title(paste(sample_num,' random FFT data points',sep=''))
	  fft_data
   }
   else if(option=='v'){
      source('view_signal.r')
      view_signal(ls)
   }
}

#Examples 1:
#  fname='UCI_EEG_database'
#
#  Press 'Ctrl + Enter'
#  Press 'Ctrl + L'
#
#  main(1,'v')
#  
#  -->And you will see the first trial's EEG signal
#
#Examples 2:
#  fname='UCI_EEG_database'
#
#  Press 'Ctrl + Enter'
#  Press 'Ctrl + L'
#
#  data<-main('r','f',5)
#  dim(data)
#
#  -->And you will get a set of 2-dimensional data points (one is averaging fft real value , and another is averaging fft imagined value) index by random choosing , and visualize their plot
#
#Examples 3:
#  fname='UCI_EEG_database'
#
#  Press 'Ctrl + Enter'
#  Press 'Ctrl + L'
#
#  data<-main('a','f')
#  dim(data)
#
#  -->And you will get a set of 2-dimensional data points (one is averaging fft real value , and another is averaging fft imagined value) index by all