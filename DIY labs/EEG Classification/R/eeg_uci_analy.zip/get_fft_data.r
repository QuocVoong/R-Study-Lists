#return fft version of data points (2-dimensions)
get_fft_data<-function(ls){
   len<-length(ls)
   avg<-get_averaging_EEG(ls)
   fft_data<-get_fft_EEG(avg)
   col_num<-dim(fft_data)[2]
   r_fft_avg1<-c()
   i_fft_avg1<-c()
   for(i in 1:len){
      r_fft_avg1<-rbind(r_fft_avg1,as.numeric(fft_data[i,3:col_num]))
	  i_fft_avg1<-rbind(i_fft_avg1,as.numeric(fft_data[(i+len),3:col_num]))
   }
   r_fft_avg<-apply(r_fft_avg1,1,mean)
   i_fft_avg<-apply(i_fft_avg1,1,mean)
   points<-rbind(r_fft_avg,i_fft_avg)
   points
}