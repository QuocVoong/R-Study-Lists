package org.guohai.maven.junit;
public class HelloJUnit {
	public String sayHello(){
		return "Hello world";
	}
}
