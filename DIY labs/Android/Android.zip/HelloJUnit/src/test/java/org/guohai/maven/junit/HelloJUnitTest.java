package org.guohai.maven.junit;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class HelloJUnitTest {

	@Test
	public void TestSayHello(){
		HelloJUnit hello=new HelloJUnit();
		String result = hello.sayHello();
		assertEquals("Hello world",result);
	}
}
