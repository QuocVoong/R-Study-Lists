function [hmm, pout] = main_test(sample, M)

    %clear;clc;
    %load('samples.mat')

    K   = length(sample);

% 计算语音参数
    disp('Calculating speech parameters...');
    for k = 1:K
    	if isfield(sample(k),'data') & ~isempty(sample(k).data)
	    	continue;
    	else
	    	sample(k).data = mfcc(sample(k).wave);
	    end
    end

%init hmm 

    N = length(M);			%状态数
    hmm.N = N;
    hmm.M = M; %hmm = {N = 4 ; M = [3 3 3 3]}

% 初始概率矩阵
    hmm.init    = zeros(N,1);
    hmm.init(1) = 1;  %hmm = {N = 4 ; M = [3 3 3 3] ; init = [1;0;0;0]}

% 转移概率矩阵
    hmm.trans=zeros(N,N);
    for i=1:N-1
	    hmm.trans(i,i)   = 0.5;
    	hmm.trans(i,i+1) = 0.5;
    end
    hmm.trans(N,N) = 1; %hmm = {N = 4 ; M = [3 3 3 3] ; init = [1;0;0;0] ; trans = [0.5 0.5 0 0;0 0.5 0.5 0;0 0 0.5 0.5;0 0 0 1]}

% 概率密度函数的初始聚类

% 平均分段(10 segments with size [1,5])
    for k = 1:K
    	T = size(sample(k).data,1);
	    sample(k).segment=floor([1:T/N:T T+1]);
	%size(sample(k).segment) = [1,5] * 10
    end

%对属于每个状态的向量进行K均值聚类,得到连续混合正态分布 (mix * 4)
    for i = 1:N
	%把相同聚类和相同状态的向量组合到一个向量中
    	vector = [];
    	for k = 1:K
    		seg1 = sample(k).segment(i);
	    	seg2 = sample(k).segment(i+1)-1;
	    	vector = [vector ; sample(k).data(seg1:seg2,:)];
	    end
	    mix(i) = getmix(vector, M(i));
	% mix(i).M = 3
	% size(mix(i).mean) = [3,24]
	% size(mix(i).var) = [3,24]
	% size(weight) = 3
    end

    hmm.mix = mix;

%size(hmm.mix(1).M) %size = [1,1]
%hmm.mix(1).mean %size = [1,1] ??
%size(hmm.mix(1).var) %size = [3,24]
%size(hmm.mix(1).weight) %size = [3,1]

    for loop = 1:40
    fprintf('\nNo.%d training\n\n',loop)
    SIZE = size(sample(1).data,2); %参数阶数

% 计算前向, 后向概率矩阵, 考虑多观察序列和下溢问题
    disp('Calculating sample parameters...');
    for k = 1:K
        fprintf('%d ',k)
	    param(k) = getparam(hmm, sample(k).data);
    end
    fprintf('\n')
%param is i*10 struct containg 'c' 'alpha' 'beta' 'ksai' 'gama'

% 重估转移概率矩阵A: trans (4*4 Matrix)
    disp('Reestimating trasport probabilistic matrix A...')
    for i = 1:N-1
    	denom = 0;
    	for k = 1:K
	    	tmp   = param(k).ksai(:,i,:);
		    denom = denom + sum(tmp(:));
	    end
	    for j = i:i+1
		    nom = 0;
		    for k = 1:K
			    tmp = param(k).ksai(:,i,j);
			    nom = nom   + sum(tmp(:));
		    end
		    hmm.trans(i,j) = nom / denom;
	    end
    end

% 重估混合高斯的参数
    disp('Reestimating mixing Gausian parameters...')
    for l = 1:N
    for j = 1:hmm.M(l)
	    fprintf('%d,%d ',l,j)
	% 计算各pdf的均值和方差
	    nommean = zeros(1,SIZE); 
	    nomvar  = zeros(1,SIZE); 
	    denom   = 0;
	    for k = 1:K
		    T = size(sample(k).data,1);
		    for t = 1:T
			    x	    = sample(k).data(t,:);
			    nommean = nommean + param(k).gama(t,l,j) * x;
			    nomvar  = nomvar  + param(k).gama(t,l,j) * (x-mix(l).mean(j,:)).^2;
			    denom   = denom   + param(k).gama(t,l,j);
		    end
	    end
	    hmm.mix(l).mean(j,:) = nommean / denom;
	    hmm.mix(l).var (j,:) = nomvar  / denom;

	% 计算各pdf的权
	    nom   = 0;
	    denom = 0;
	    for k = 1:K
		    tmp = param(k).gama(:,l,j);    nom   = nom   + sum(tmp(:));
		    tmp = param(k).gama(:,l,:);    denom = denom + sum(tmp(:));
	    end
	    hmm.mix(l).weight(j) = nom/denom;
    end
    fprintf('\n')
    end

%计算总输出概率
    pout(loop)=0;
    for k = 1:K
	    pout(loop) = pout(loop) + viterbi(hmm, sample(k).data);
    end

    fprintf('Total output probability(log)=%d\n', pout(loop))

%比较两个HMM的距离
    if loop>1
	    if abs((pout(loop)-pout(loop-1))/pout(loop)) < 5e-6
		    fprintf('Converge!\n');
		    return
	    end
    end

    end

    disp('Finish training')

% Function 'getmix'

function mix = getmix(vector, M)

[mean esq nn] = kmeanlbg(vector,M);

% 计算每个聚类的标准差, 对角阵, 只保存对角线上的元素
for j = 1:M
	ind = find(j==nn);
	tmp = vector(ind,:);
	var(j,:) = std(tmp);
end

% 计算每个聚类中的元素数, 归一化为各pdf的权重
weight = zeros(M,1);
for j = 1:M
	weight(j) = sum(find(j==nn));
end
weight = weight/sum(weight);

% 保存结果
mix.M      = M;
%M
mix.mean   = mean.^1;		% M*SIZE , Let the mean become [3,24]
%size(mean)
mix.var    = var.^2;	% M*SIZE
%size(var)
mix.weight = weight;	% M*1
%size(weight)